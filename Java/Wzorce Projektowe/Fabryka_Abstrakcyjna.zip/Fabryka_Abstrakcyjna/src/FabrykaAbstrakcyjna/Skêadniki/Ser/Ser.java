package FabrykaAbstrakcyjna.Składniki.Ser;

import FabrykaAbstrakcyjna.Składniki.Ciasto.Ciasto;

public interface Ser {
    public Ser zróbSer();
    public String getNazwa();
}
