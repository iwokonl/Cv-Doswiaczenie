package FabrykaAbstrakcyjna.Składniki.Małże;

import FabrykaAbstrakcyjna.Składniki.Ciasto.Ciasto;

public interface Małże {
    public Małże zróbMałże();
    public String getNazwa();
}
