package PrzykładDIP.NieDIP;

class MargheritaPizza {
    void preparePizza() {
        System.out.println("Preparing Margherita Pizza");
    }
}
