package PrzykładDIP.DIP;

interface Pizza {
    void preparePizza();
}
