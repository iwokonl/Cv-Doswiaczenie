package PrzykładDIP.DIP;



class MargheritaPizza implements Pizza {
    public void preparePizza() {
        System.out.println("Preparing Margherita Pizza");
    }
}