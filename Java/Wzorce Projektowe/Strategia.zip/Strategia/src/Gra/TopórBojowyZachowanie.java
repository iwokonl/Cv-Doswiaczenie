package Gra;

public class TopórBojowyZachowanie implements BrońZachowanie{
    @Override
    public void uzyjBroni() {
        System.out.println("Bije toporem bojowym");
    }
}
