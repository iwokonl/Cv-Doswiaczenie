package Gra;

public interface BrońZachowanie {
    public void uzyjBroni();
}
