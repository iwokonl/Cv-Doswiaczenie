package Gra;

public class MaczugaZachowanie implements BrońZachowanie{
    @Override
    public void uzyjBroni() {
        System.out.println("bije maczugą");
    }
}
