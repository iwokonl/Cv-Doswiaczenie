package Gra;

public class MieczZachowanie implements BrońZachowanie{
    @Override
    public void uzyjBroni() {
        System.out.println("Bije mieczem");
    }
}
