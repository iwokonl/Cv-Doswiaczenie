package Gra;

public class NóżZachowanie implements BrońZachowanie {
    @Override
    public void uzyjBroni() {
        System.out.println("Bije maczugą");
    }
}
