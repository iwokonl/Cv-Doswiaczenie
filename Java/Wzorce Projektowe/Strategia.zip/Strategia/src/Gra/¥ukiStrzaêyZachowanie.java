package Gra;

public class ŁukiStrzałyZachowanie implements BrońZachowanie {
    @Override
    public void uzyjBroni() {
        System.out.println("Bije łukiem");
    }
}
