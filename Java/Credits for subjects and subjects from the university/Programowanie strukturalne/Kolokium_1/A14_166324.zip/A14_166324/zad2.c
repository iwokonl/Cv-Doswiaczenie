#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n = 0;
    int m = 0;
    int ile = 1;
    scanf("%d", &m);
    scanf("%d", &n);
    double temp =  (double) n;
    while(temp < (double) m){
        temp *= (double) ((double) m/ (double) n);
        ile++;
    }
    printf("%d", ile);
    return 0;
}
