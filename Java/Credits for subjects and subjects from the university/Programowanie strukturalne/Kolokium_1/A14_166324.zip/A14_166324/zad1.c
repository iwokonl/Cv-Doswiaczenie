#include <stdio.h>
#include <stdlib.h>

int foo(int*a,int*b)
{
    return *a**b;
}

int main()
{
    int tab[] = {2,2,1,0,3,3,-4,-4,0,1};
    int *wsk=tab-1;
    int b = *(wsk+=4); //b= 0
    int c = b+3; // b= 0 , c= 3
    int d = foo(&b,&c); // b= 0 , c= 3 , d= 0
    int e = (wsk+=-1)[4]; // b= 0 , c= 3 , d= 0 , e= -4
    e = (d -= 2) + (c += 2); // b= 0 , c= 5 , d= -2 , e=3
    c = d + (b+=4); // b= 4 , c= 2 , d= -2 , e= 3
    e= (--c)-(d++);  // b= 4 , c= 1 , d= -1 , e= 3
    b = *wsk + e; // b= 4 , c= 1 , d= -1 , e=3
    return 0;
}
