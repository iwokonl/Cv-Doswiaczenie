#include <stdio.h>
#include <stdlib.h>
double subtract_pointed_numbers(const double *num1, double *const num2){
    return *num1 - *num2;

}
int main()
{
    double x = 1.0;
    double y = 2.0;

    printf("%lf\n", subtract_pointed_numbers(&x,&y));
    return 0;
}
