#include <stdio.h>
#include <stdlib.h>
int foo(int n){
    if(n == 0)
        return 7;
    return foo(n-1) -8;
}
int main()
{
    printf("n = 3 foo = %d\n", foo(3));
    printf("n = 2 foo = %d\n", foo(2));
    return 0;
}
