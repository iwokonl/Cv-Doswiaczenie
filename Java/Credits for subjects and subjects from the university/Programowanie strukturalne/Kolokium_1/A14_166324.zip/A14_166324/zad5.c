#include <stdio.h>
#include <stdlib.h>
int foo(int n, int *tab){
    if(n % 2 == 0){
        for(int i = 0;i<n;i++){
            if(*(tab + i) != *(tab + (n - i - 1)))
                return 0;
        }
    }
    else{
        for(int i = 0;i<n;i++){
            if(i != (n - 1)/2){
            if(*(tab + i) != *(tab + (n - i - 1)))
                return 0;
        }
        }
    }
    return 1;

}
int main()
{
    int n = 5;
    int *tab = (int*) malloc(sizeof(int)*5);
    *(tab + 0) = 1;
    *(tab + 1) = 1;
    *(tab + 2) = 2;
    *(tab + 3) = 1;
    *(tab + 4) = 1;
    printf("%d", foo(n,tab));
    return 0;
}
