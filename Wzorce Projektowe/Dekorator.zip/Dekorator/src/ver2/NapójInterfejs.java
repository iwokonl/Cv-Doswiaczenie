package ver2;

public interface NapójInterfejs {
    String opis();
    double cena();
}
