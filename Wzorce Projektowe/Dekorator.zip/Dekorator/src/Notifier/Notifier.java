package Notifier;

public interface Notifier {
    void send();
}
