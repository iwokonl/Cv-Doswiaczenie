package ver1;

public abstract class SkładnikDekorator extends Napój{
    public Napój napój;
    @Override
    public abstract double koszt();
}
