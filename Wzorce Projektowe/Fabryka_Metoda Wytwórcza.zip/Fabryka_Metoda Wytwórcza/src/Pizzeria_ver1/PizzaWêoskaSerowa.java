package Pizzeria_ver1;

public class PizzaWłoskaSerowa extends Pizza {
    public PizzaWłoskaSerowa(){
        nazwa= "Włoska";
        ciasto = "cienkie";
        sos = "makaronowy";

        dodatki.add("Jakiś drogi dodatek");
    }
}
