package ver2;

public class PizzaWłoskaSerowa extends Pizza {
    public PizzaWłoskaSerowa(){
        nazwa= "Pizza Włoska";
        ciasto = "cienkie";
        sos = "makaronowy";

        dodatki.add("Jakiś drogi dodatek");
    }
}
