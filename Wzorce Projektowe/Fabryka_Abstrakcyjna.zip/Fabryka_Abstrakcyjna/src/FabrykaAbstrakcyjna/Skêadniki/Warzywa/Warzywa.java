package FabrykaAbstrakcyjna.Składniki.Warzywa;

import FabrykaAbstrakcyjna.Składniki.Małże.Małże;

public interface Warzywa {
    public Warzywa zróbWarzywa();
    public String getNazwa();
}
