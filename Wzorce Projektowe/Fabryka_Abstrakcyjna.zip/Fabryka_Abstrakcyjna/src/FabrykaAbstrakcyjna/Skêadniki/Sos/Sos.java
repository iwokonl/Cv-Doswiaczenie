package FabrykaAbstrakcyjna.Składniki.Sos;

import FabrykaAbstrakcyjna.Składniki.Ciasto.Ciasto;

public interface Sos {
    public Sos zróbSos();
    public String getNazwa();
}
