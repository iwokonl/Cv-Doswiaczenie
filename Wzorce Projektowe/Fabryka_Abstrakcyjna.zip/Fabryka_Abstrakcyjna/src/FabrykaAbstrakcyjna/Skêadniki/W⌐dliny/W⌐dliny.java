package FabrykaAbstrakcyjna.Składniki.Wędliny;

import FabrykaAbstrakcyjna.Składniki.Sos.Sos;

public interface Wędliny {
    public Wędliny zróbWędliny();
    public String getNazwa();
}
