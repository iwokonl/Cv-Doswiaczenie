package FabrykaAbstrakcyjna.Składniki.Ciasto;

public interface Ciasto {

    public Ciasto zróbCiasto();
    public String getNazwa();

}
