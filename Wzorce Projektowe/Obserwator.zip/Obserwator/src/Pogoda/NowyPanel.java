package Pogoda;

public class NowyPanel implements PanelObserwacyjny, Obserwator{
    @Override
    public void aktualizacja() {

    }

    @Override
    public void wyświetl() {

    }
}
