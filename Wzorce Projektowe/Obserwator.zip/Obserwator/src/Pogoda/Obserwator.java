package Pogoda;

public interface Obserwator {
    void aktualizacja();
}
