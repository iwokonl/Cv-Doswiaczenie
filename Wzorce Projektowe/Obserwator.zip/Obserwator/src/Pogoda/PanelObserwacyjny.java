package Pogoda;

public interface PanelObserwacyjny {
    void wyświetl();
}
